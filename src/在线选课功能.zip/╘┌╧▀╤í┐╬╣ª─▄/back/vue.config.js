module.exports={
	devServer:{
		port:8848,
		host:"127.0.0.1"
	}
	
}