<template>
	<div>
		<img alt="Vue logo" src="img/logo.png"><br />
		欢迎使用在线报名系统后台管理
	</div>
</template>
<script>
</script>
<style type="text/css" scoped="scoped">
	div {
		text-align: center;
		font-weight: bold;
		font-size: 40px;
	}
</style>
