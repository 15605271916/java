<template>
	<Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
		<FormItem label="账号" prop="account">
			<Input disabled v-model="formValidate.account" placeholder="请输入账号"></Input>
		</FormItem>
		<FormItem label="新密码" prop="pwd1">
			<Input type="password" v-model="formValidate.pwd1" placeholder="请输入新密码"></Input>
		</FormItem>
		<FormItem label="密码确认" prop="pwd2">
			<Input type="password" v-model="formValidate.pwd2" placeholder="请再次输入新密码"></Input>
		</FormItem>
		<FormItem label="姓名" prop="name">
			<Input v-model="formValidate.name" placeholder="请输入姓名"></Input>
		</FormItem>
		<FormItem label="性别" prop="sex">
			<RadioGroup v-model="formValidate.sex">
				<Radio label="男">男</Radio>
				<Radio label="女">女</Radio>
			</RadioGroup>
		</FormItem>
		<FormItem>
			<Button type="primary" @click="handleSubmit('formValidate')">确认</Button>
			<Button @click="handleReset('formValidate')" style="margin-left: 8px">取消</Button>
		</FormItem>
	</Form>
</template>
<script>
	export default {
		data() {
			const validatePass = (rule, value, callback) => {
				if (value === '') {
					callback(new Error('请输入密码'));
				} else {
					if (this.formValidate.pwd2 !== '') {
						// 对第二个密码框单独验证
						this.$refs.formValidate.validateField('pwd2');
					}
					callback();
				}
			};
			const validatePassCheck = (rule, value, callback) => {
				if (value === '') {
					callback(new Error('请再次输入密码'));
				} else if (value !== this.formValidate.pwd1) {
					callback(new Error('密码不一致'));
				} else {
					callback();
				}
			};
			return {
				formValidate: {
					account: '',
					pwd1: '',
					pwd2: '',
					name: '',
					sex: ''
				},
				ruleValidate: {

					name: [{
						required: true,
						message: '姓名不能为空',
						trigger: 'blur'
					}],
					pwd1: [{
						validator: validatePass,
						trigger: 'blur'
					}],
					pwd2: [{
						validator: validatePassCheck,
						trigger: 'blur'
					}],
					gender: [{
						required: true,
						message: 'Please select gender',
						trigger: 'change'
					}],

				}
			}
		},
		mounted() {
			var account = this.$route.query.account;
			var users = localStorage.getItem("users");
			users = JSON.parse(users);
			for (var user of users) {
				if (account == user.account) {
					this.formValidate.account = user.account;
					this.formValidate.pwd1 = user.pwd;
					this.formValidate.pwd2 = user.pwd;
					this.formValidate.name = user.name;
					this.formValidate.sex = user.sex;
					break;
				}
			}
		},
		methods: {
			handleSubmit(name) {
				this.$refs[name].validate((valid) => {
					if (valid) {
						var u = this.formValidate;
						var users = localStorage.getItem("users");
						users = JSON.parse(users);
						for (var i = 0; i < users.length; i++) {
							if (users[i].account == u.account) {
								users[i].account = u.account;
								users[i].pwd = u.pwd1;
								users[i].sex = u.sex;
								users[i].name = u.name;
								break;
							}
						}
						localStorage.setItem("users",JSON.stringify(users))
						this.$Message.success('修改成功');
					}
				})
			},
			handleReset(name) {
				this.$refs[name].resetFields();
			}
		}
	}
</script>
