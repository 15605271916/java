<template>
	<Table border :columns="columns12" :data="data6">
		<template slot-scope="{ row }" slot="account">
			<strong>{{ row.account}}</strong>
		</template>
		<template slot-scope="{ row, index }" slot="action">
			<Button type="primary" size="small" style="margin-right: 5px" @click="show( row.account)">修改</Button>
			<Button type="error" size="small" @click="remove(index)">删除</Button>
		</template>
	</Table>
</template>
<script>
	export default {
		data() {
			return {
				columns12: [{
						title: '账号',
						slot: 'account'
					},
					{
						title: '姓名',
						key: 'name'
					},
					{
						title: '性别',
						key: 'sex'
					},
					{
						title: '操作',
						slot: 'action',
						width: 150,
						align: 'center'
					}
				],
				data6: []
			}
		},
		mounted() {
			var users = localStorage.getItem("users")
			users = JSON.parse(users);
			if (users != null) {
				this.data6 = users;
			}
		},
		methods: {
			show(account) {

				this.$router.push({
					path: "/Useredit",
					query: {
						account: account
					}
				});
			},
			remove(index) {
				this.$Modal.confirm({
					title: "提示",
					content: "确认删除吗？",
					onOk: ()=> {
						var users=localStorage.getItem("users");
						users=JSON.parse(users);
						users.splice(index,1 );
						localStorage.setItem("users",JSON.stringify(users));
						
						this.data6.splice(index, 1);
					}
				});
			}
		}
	}
</script>
