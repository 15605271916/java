<template>
	<Table border :columns="columns12" :data="data6">
		<template slot-scope="{ row }" slot="img">
			<img :src="'img/'+row.img" />
		</template>
		<template slot-scope="{ row }" slot="flag">
			<Tag v-if="row.flag=='等待审核'" color="warning">{{row.flag}}</Tag>
			<Tag v-else-if="row.flag=='同意学习'" color="success">{{row.flag}}</Tag>
			<Tag v-else color="error">{{row.flag}}</Tag>
		</template>
		<template v-if="row.flag=='等待审核'" slot-scope="{ row, index }" slot="action">
			<Button type="success" size="small" @click="agree(index)">同 意</Button> &nbsp;
			<Button type="error" size="small" @click="refuse(index)">删 除</Button>
		</template>
	</Table>
</template>
<script>
	export default {
		data() {
			return {
				columns12: [{
						title: '图片',
						slot: 'img',
						width: 120,
						align: 'center'
					},
					{
						title: '课程名称',
						key: 'courseName'
					},
					{
						title: '用户名',
						key: 'account'
					},
					{
						title: '状态',
						slot: 'flag',
						key: 'flag'
					},
					{
						title: '操作',
						slot: 'action',
						width: 150,
						align: 'center'
					}
				],
				data6: []
			}
		},
		mounted() {
			var applyed = localStorage.getItem("userApply");
			applyed = JSON.parse(applyed);
			for (var account in applyed) {
				//通过account获取课程
				var applyedCourse = applyed[account];
				for (var {
						id,
						flag
					} of applyedCourse) {
					var courseList = localStorage.getItem("courseList");
					courseList = JSON.parse(courseList);
					for (var course of courseList) {
						if (course.id == id) {
							var applyedVO = {
								id: id,
								img: course.img,
								courseName: course.name,
								account: account,
								flag: flag
							}
							this.data6.push(applyedVO);
							break;
						}
					}
				}
			}
		},
		methods: {
			show(index) {
				this.$Modal.info({
					title: 'User Info',
					content: `Name：${this.data6[index].name}<br>Age：${this.data6[index].age}<br>Address：${this.data6[index].address}`
				})
			},
			agree(index) {
				// 同意学习
				this.data6. [index].flag = "同意学习";
				var account = this.data6[index].account;
				var id = this.data6[index].id;
				var applyed = localStorage.getItem("userApply");
				applyed = JSON.parse(applyed);
				for (var i = 0; i < applyed[account].length; i++) {
					if (id == applyed[account][i].id) {
						applyed[account][i].flag = "同意学习"
						break;
					}
				}
				localStorage.setItem("userApply", JSON.stringify(applyed))
			},

			refuse(index) {
				// 拒绝学习
				this.data6. [index].flag = "拒绝学习";
				var account = this.data6[index].account;
				var id = this.data6[index].id;
				var applyed = localStorage.getItem("userApply");
				applyed = JSON.parse(applyed);
				for (var i = 0; i < applyed[account].length; i++) {
					if (id == applyed[account][i].id) {
						applyed[account][i].flag = "拒绝学习"
						break;
					}
				}
				localStorage.setItem("userApply", JSON.stringify(applyed))
			}
		}
	}
</script>

<style scoped="scoped">
	img {
		width: 80px;
		height: 80px;

	}
</style>
